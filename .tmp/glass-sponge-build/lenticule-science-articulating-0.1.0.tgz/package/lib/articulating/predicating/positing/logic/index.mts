/**
 * positing/logic — value-level multiplicative linear logic over FOUR.
 *
 * This module exports the finite charge-value alphabet operations and
 * witness/obstruction judgments from `bilattice-linear-logic.mjs`: fusion,
 * residuum, linear negation, par, consistency, and truth-order residuation.
 *
 * Fiber-level lifting lives in `positing/fiber`; the Chu-space category and
 * tensor/hom proofs live in `RelMath.Order.LinearLogicChu`. This module is not
 * a proof-net or sequent-calculus engine.
 *
 * @packageDocumentation
 */
export * from "./bilattice-linear-logic.mjs";
